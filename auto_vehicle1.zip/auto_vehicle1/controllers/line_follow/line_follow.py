from controller import Robot


TIME_STEP = 64
max_speed = 6.28

robot = Robot()
ir = []
irNames = ['ir_right', 'ir_left']
for i in range(2):
    ir.append(robot.getDevice(irNames[i]))
    ir[i].enable(TIME_STEP)
wheels = []
wheelsNames = ['wheel1', 'wheel2', 'wheel3', 'wheel4']
for i in range(4):
    wheels.append(robot.getDevice(wheelsNames[i]))
    wheels[i].setPosition(float('inf'))
    wheels[i].setVelocity(0.0)

while robot.step(TIME_STEP) != -1:
    left_ir_value = ir[1].getValue()
    right_ir_value = ir[0].getValue()
    leftSpeed = max_speed * 0.25
    rightSpeed = max_speed * 0.25
    
    print("left:{} right:{}".format(left_ir_value, right_ir_value))
    
    if (left_ir_value > right_ir_value) and (6 < left_ir_value < 15):
        leftSpeed = -max_speed * 0.25
    elif (right_ir_value > left_ir_value) and (6 < right_ir_value < 15):
        rightSpeed = -max_speed * 0.25	
    
    wheels[0].setVelocity(leftSpeed)
    wheels[1].setVelocity(rightSpeed)
    wheels[2].setVelocity(leftSpeed)
    wheels[3].setVelocity(rightSpeed)

