import cv2

thres = 0.45  # Threshold to detect object

cap = cv2.VideoCapture(0)
cap.set(3, 1280)
cap.set(4, 720)
cap.set(10, 70)

classNames = []
classFile = 'coco.names'
with open(classFile, 'rt') as f:
    classNames = f.read().rstrip('\n').split('\n')

configPath = 'ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt'
weightsPath = 'frozen_inference_graph.pb'

net = cv2.dnn_DetectionModel(weightsPath, configPath)
net.setInputSize(320, 320)
net.setInputScale(1.0 / 127.5)
net.setInputMean((127.5, 127.5, 127.5))
net.setInputSwapRB(True)


def face_data(image):
    face_width = 0  # making face width to zero

    # converting color image ot gray scale image
    gray_image = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)

    # detecting face in the image
    faces = face_detector.detectMultiScale(image, 1.3, 5)

    # looping through the faces detect in the image
    # getting coordinates x, y , width and height
    for (x, y, h, w) in faces:
        # draw the rectangle on the face
        cv2.rectangle(image, (x, y), (x + w, y + h), GREEN, 2)

        # getting face width in the pixels
        face_width = w

    # return the face width in pixel
    return face_width


def Focal_Length_Finder(measured_distance, real_width, width_in_rf_image):
    # finding the focal length
    focal_length = (width_in_rf_image * measured_distance) / real_width
    return focal_length


def Distance_finder(Focal_Length, real_face_width, face_width_in_frame):
    distance = (real_face_width * Focal_Length) / face_width_in_frame

    # return the distance
    return distance



while True:
    success, img = cap.read()
    classIds, confs, bbox = net.detect(img, confThreshold=thres)
    print(classIds)

    if len(classIds) != 0:
        for classId, confidence, box in zip(classIds.flatten(), confs.flatten(), bbox):
            if classId == 1:

                fonts = cv2.FONT_HERSHEY_COMPLEX
                GREEN = (0, 255, 0)
                RED = (0, 0, 255)
                WHITE = (255, 255, 255)
                BLACK = (0, 0, 0)
                face_detector = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
                Known_distance = 20
                Known_width = 6

                # reading reference_image from directory
                ref_image = cv2.imread("Ref_image.png")

                # find the face width(pixels) in the reference_image
                ref_image_face_width = face_data(ref_image)

                # calling face_data function to find
                # the width of face(pixels) in the frame
                face_width_in_frame = face_data(img)

                Focal_length_found = Focal_Length_Finder(Known_distance, Known_width, ref_image_face_width)

                # check if the face is zero then not
                # find the distance
                if face_width_in_frame != 0:
                    # finding the distance by calling function
                    # Distance distnace finder function need
                    # these arguments the Focal_Length,
                    # Known_width(centimeters),
                    # and Known_distance(centimeters)
                    Distance = Distance_finder(Focal_length_found, Known_width, face_width_in_frame)

                    # draw line as background of text
                    #cv2.line(frame, (30, 30), (230, 30), RED, 32)
                    #cv2.line(frame, (30, 30), (230, 30), BLACK, 28)

                    # Drawing Text on the screen
                    cv2.putText(
                        img, f"Distance: {round(Distance, 2)} IN", (30, 35),
                        fonts, 0.6, RED, 2)
            """if classId == 3:
                fonts = cv2.FONT_HERSHEY_COMPLEX
                GREEN = (0, 255, 0)
                RED = (0, 0, 255)
                WHITE = (255, 255, 255)
                BLACK = (0, 0, 0)
                face_detector = cv2.CascadeClassifier("cars.xml")
                Known_distance = 10
                Known_width = 6

                # reading reference_image from directory
                ref_image = cv2.imread("Car_ref_image.jpg")

                # find the face width(pixels) in the reference_image
                ref_image_face_width = face_data(ref_image)

                # calling face_data function to find
                # the width of face(pixels) in the frame
                face_width_in_frame = face_data(img)
                print("Face Width in Frame: ", face_width_in_frame)

                Focal_length_found = Focal_Length_Finder(Known_distance, Known_width, ref_image_face_width)
                print("Focal length found: ", face_width_in_frame)

                # check if the face is zero then not
                # find the distance
                if face_width_in_frame != 0:
                    # finding the distance by calling function
                    # Distance distnace finder function need
                    # these arguments the Focal_Length,
                    # Known_width(centimeters),
                    # and Known_distance(centimeters)
                    Distance = Distance_finder(Focal_length_found, Known_width, face_width_in_frame)
                    print("Distance: ", Distance)

                    # draw line as background of text
                    # cv2.line(frame, (30, 30), (230, 30), RED, 32)
                    # cv2.line(frame, (30, 30), (230, 30), BLACK, 28)

                    # Drawing Text on the screen
                    cv2.putText(
                        img, f"Distance: {round(Distance, 2)} FT", (30, 35),
                        fonts, 0.6, RED, 2)"""

            cv2.rectangle(img, box, color=(0, 255, 0), thickness=2)
            cv2.putText(img, classNames[classId - 1].upper(), (box[0] + 10, box[1] + 30),
                        cv2.FONT_HERSHEY_COMPLEX, 1, (0, 255, 0), 2)
            cv2.putText(img, str(round(confidence * 100, 2)), (box[0] + 200, box[1] + 30),
                        cv2.FONT_HERSHEY_COMPLEX, 1, (0, 255, 0), 2)

    cv2.imshow("Output", img)
    cv2.waitKey(1)